<?php $__env->startSection('title', 'Catálogo de Bienestar Premium'); ?>

<?php $__env->startPush('styles'); ?>
  
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/modal.css']); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="modulo-vista">

    
    <header class="encabezado-modulo">
        <div>
            <h1>Nuestras Terapias y Experiencias</h1>
            <p>Selecciona el tratamiento ideal para restaurar tu equilibrio corporal y estético.</p>
        </div>

        
        <?php if(auth()->user()->rol === 'admin'): ?>
            <button type="button" class="btn-agregar-servicio" onclick="abrirModalAgregarServicio()">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
                Agregar Servicio
            </button>
        <?php endif; ?>
    </header>

    
    <?php if(session('success')): ?>
        <div id="mensaje-exito-oculto" data-mensaje="<?php echo e(session('success')); ?>" style="display: none;"></div>
    <?php endif; ?>

    
    <section class="rejilla-catalogo" id="contenedor-servicios-catalogo">

        <?php $__empty_1 = true; $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $nombreServicio = $servicio->nombre_servicio;
                $idSimulado = $servicio->id;
                $precioSimulado = $servicio->precio;
                $descripcionSimulada = $servicio->descripcion ?? '';

                // Duración con rango legible
                $duracion = (int) $servicio->duracion_minutos;
                $tiempoEstimadoSimulado = match($duracion) {
                    45  => "30 min - 50 min",
                    75  => "60 min - 90 min",
                    105 => "90 min - 120 min",
                    150 => "120 min - 180 min",
                    default => $duracion . " min"
                };

                // Porcentaje de abono real si existe, sino 10 por defecto
                $porcentajeAgendadoSimulado = $servicio->porcentaje_abono ?? 10;

                // Especialistas reales del servicio (relación belongsToMany)
                $especialistasColeccion    = $servicio->especialistas ?? collect();
                $especialistasSimulados    = $especialistasColeccion->pluck('nombre')->toArray();
                $especialistasIdsSimulados = $especialistasColeccion->pluck('id')->toArray();
            ?>

            
            <article class="tarjeta-servicio-item"
                     data-id="<?php echo e($idSimulado); ?>"
                     data-nombre="<?php echo e($nombreServicio); ?>"
                     data-precio="<?php echo e($precioSimulado); ?>"
                     data-porcentaje="<?php echo e($porcentajeAgendadoSimulado); ?>"
                     data-tiempo="<?php echo e($tiempoEstimadoSimulado); ?>"
                     data-descripcion="<?php echo e($descripcionSimulada); ?>"
                     data-especialistas-nombres='<?php echo e(json_encode($especialistasSimulados)); ?>'
                     data-especialistas-ids='<?php echo e(json_encode($especialistasIdsSimulados)); ?>'>

                
                <div class="contenedor-imagen-spa">
                    <img src="<?php echo e($servicio->imagen ? asset('storage/' . $servicio->imagen) : asset('asset/img/parts/antiage.jpg')); ?>"
                         alt="<?php echo e($nombreServicio); ?>"
                         class="foto-servicio-portada">
                    <span class="badge-categoria-flotante">Premium</span>
                </div>

                
                <div class="info-servicio-body">
                    <h3 class="titulo-servicio-spa"><?php echo e($nombreServicio); ?></h3>
                    <p class="descripcion-servicio-spa"><?php echo e($descripcionSimulada); ?></p>

                    <div class="detalles-servicio">
                        <span class="tiempo-servicio">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <?php echo e($tiempoEstimadoSimulado); ?>

                        </span>
                        <span class="precio-tag">$<?php echo e($precioSimulado); ?></span>
                    </div>
                </div>

                
                <footer class="footer-tarjeta">
                    <div class="acciones-catalogo-wrapper">
                        <button type="button" class="btn-secundario" onclick="verServicioDetalle('<?php echo e($idSimulado); ?>')">
                            Consultar
                        </button>

                        <?php if(auth()->user()->rol === 'cliente'): ?>
                            <a href="<?php echo e(route('clientes.reserva')); ?>?servicio_id=<?php echo e($idSimulado); ?>&nombre=<?php echo e(urlencode($nombreServicio)); ?>&precio=<?php echo e($precioSimulado); ?>&porcentaje=<?php echo e($porcentajeAgendadoSimulado); ?>" class="btn-primario">
                                Reservar
                            </a>

                        <?php elseif(auth()->user()->rol === 'admin'): ?>
                            
                            <button type="button" class="btn-icono-accion btn-editar" onclick="editarServicio('<?php echo e($idSimulado); ?>')" title="Editar Servicio">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                </svg>
                            </button>

                            
                            <button type="button" class="btn-icono-accion btn-eliminar" onclick="eliminarServicio('<?php echo e($idSimulado); ?>')" title="Eliminar Servicio">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                            </button>

                        <?php elseif(auth()->user()->rol === 'recepcion'): ?>
                            
                            <a href="<?php echo e(route('clientes.reserva')); ?>?servicio_id=<?php echo e($idSimulado); ?>&nombre=<?php echo e(urlencode($nombreServicio)); ?>&precio=<?php echo e($precioSimulado); ?>&porcentaje=<?php echo e($porcentajeAgendadoSimulado); ?>" class="btn-primario">
                                Agendar Cita
                            </a>
                        <?php endif; ?>
                    </div>
                </footer>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="text-align: center; color: var(--spa-text-muted); grid-column: 1 / -1; padding: 3rem;">
                No se encontraron servicios disponibles en este momento.
            </p>
        <?php endif; ?>
    </section>
</section>


<?php if(auth()->user()->rol === 'cliente'): ?>
<dialog id="onboardingBienvenida" class="onboarding-bienvenida">

    
    <div class="onboarding-marca">
        <div class="logo-circulo">BR</div>
        <span class="nombre-marca">The Beauty Room</span>
    </div>

    
    <div class="onboarding-tarjeta">

        
        <button type="button" class="onboarding-cerrar" id="onboardingCerrar" aria-label="Cerrar">×</button>

        
        <aside class="onboarding-lado-oscuro">
            <span class="onboarding-numero" id="onboardingNumero">01</span>

            <div class="onboarding-icono-circulo" id="onboardingIcono">
                
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 3v3m0 12v3m9-9h-3M6 12H3m15.364-6.364l-2.121 2.121M8.757 15.243l-2.121 2.121m12.728 0l-2.121-2.121M8.757 8.757L6.636 6.636"/>
                    <circle cx="12" cy="12" r="3"/>
                </svg>
            </div>

            <div class="onboarding-frase">
                Your Beauty,<br>Your Moment
            </div>
        </aside>

        
        <div class="onboarding-lado-claro">

            <div class="onboarding-contenido">

                
                <div class="onboarding-progreso" id="onboardingProgreso">
                    <span class="linea activa"></span>
                    <span class="linea"></span>
                    <span class="linea"></span>
                </div>

                
                <div class="onboarding-paso activo" data-paso="1">
                    <span class="onboarding-etiqueta">Descubre</span>
                    <p class="onboarding-subtitulo">Bienvenida a The Beauty Room</p>
                    <h2 class="onboarding-titulo">Explora nuestros rituales</h2>
                    <p class="onboarding-descripcion">
                        Conoce todos nuestros servicios, sus beneficios, duración y precio
                        antes de elegir.
                    </p>
                </div>

                
                <div class="onboarding-paso" data-paso="2">
                    <span class="onboarding-etiqueta">Conecta</span>
                    <p class="onboarding-subtitulo">Conoce a nuestras expertas</p>
                    <h2 class="onboarding-titulo">Encuentra tu match ideal</h2>
                    <p class="onboarding-descripcion">
                        Revisa el perfil y las especialidades de cada profesional para
                        encontrar a la terapeuta perfecta para ti.
                    </p>
                </div>

                
                <div class="onboarding-paso" data-paso="3">
                    <span class="onboarding-etiqueta">Reserva</span>
                    <p class="onboarding-subtitulo">Agenda en pocos pasos</p>
                    <h2 class="onboarding-titulo">Tu momento te espera</h2>
                    <p class="onboarding-descripcion">
                        Elige servicio, fecha y hora. Recibirás tu confirmación
                        inmediatamente por correo.
                    </p>
                </div>

            </div>

            
            <footer class="onboarding-pie">
                <span class="onboarding-paso-texto" id="onboardingPasoTexto">Paso 1 de 3</span>

                <button type="button" class="onboarding-btn-continuar" id="onboardingContinuar">
                    <span id="onboardingBtnTexto">Continuar</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M5 12h14M13 5l7 7-7 7"/>
                    </svg>
                </button>
            </footer>

        </div>

    </div>

    
    <p class="onboarding-nota">Este recorrido solo aparecerá esta vez.</p>

</dialog>
<?php endif; ?>

<?php echo $__env->make('compartidas.modal-catalogo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/catalogo.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gestorCitas-\resources\views/compartidas/catalogo.blade.php ENDPATH**/ ?>