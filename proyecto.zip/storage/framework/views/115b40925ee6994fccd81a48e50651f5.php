<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cita cancelada</title>
</head>
<body style="margin: 0; padding: 24px; background: #f6f3eb; color: #333; font-family: Arial, sans-serif;">
    
    <main style="max-width: 600px; margin: 0 auto; padding: 32px; border-radius: 12px; background: #fff;">
        
        <h1 style="color: #8b5e3c;">¡Tu cita ha sido cancelada, <?php echo e($cita->cliente->nombre); ?>!</h1>
        
        <p>El equipo de The Beauty Room canceló tu cita para <strong><?php echo e($cita->servicio->nombre_servicio ?? 'tu servicio'); ?></strong>.</p>
        <p>
            
            <strong>Fecha:</strong> <?php echo e($cita->fecha->format('d/m/Y')); ?><br>
            
            <strong>Hora:</strong> <?php echo e(\Carbon\Carbon::parse($cita->hora)->format('h:i A')); ?>

        </p>
        <?php if($motivo): ?>
            
            <p><strong>Motivo de cancelación:</strong> <?php echo e($motivo); ?></p>
        <?php endif; ?>
        <?php if($montoReembolso > 0 && $reembolsoPorDefinir): ?>
            <p>
                Se te reembolsará un importe de <strong>$<?php echo e(number_format($montoReembolso, 2)); ?></strong>.
                El monto adicional aún está por definirse; te informaremos cuando quede confirmado.
            </p>
        <?php elseif($montoReembolso > 0): ?>
            <p>
                Se te reembolsará <strong>$<?php echo e(number_format($montoReembolso, 2)); ?></strong>.
                El reembolso está pendiente de procesarse.
            </p>
        <?php elseif($reembolsoPorDefinir): ?>
            <p>
                Se gestionará un reembolso por tu pago. El importe está pendiente de definición
                y te informaremos cuando quede confirmado.
            </p>
        <?php endif; ?>
        
        <p>Si tienes dudas, comunícate con The Beauty Room.</p>
        
        <p style="color: #777;">The Beauty Room</p>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\gestorCitas-\resources\views/emails/cita-cancelada.blade.php ENDPATH**/ ?>