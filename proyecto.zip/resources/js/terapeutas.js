/**
 * MÓDULO: Gestión de Terapeutas - Vista Pública y Dashboard
 */

document.addEventListener("DOMContentLoaded", function() {
    console.log('✅ Módulo de terapeutas cargado');

    // --- LECTURA DE MENSAJES DE ÉXITO (SweetAlert) ---
    // Esto atrapa el mensaje que Laravel envía al guardar o editar un especialista
    const mensajeExito = document.getElementById("dashboard-mensaje-exito");
    if (mensajeExito) {
        const texto = mensajeExito.dataset.mensaje;
        if (texto && typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'success',
                title: '¡Excelente!',
                text: texto,
                confirmButtonColor: '#8b5e3c',
                confirmButtonText: 'Aceptar'
            });
        }
    }

    const form = document.getElementById('form-terapeuta');
    const passwordInput = document.getElementById('password');
    const passwordConfirmationInput = document.getElementById('password_confirmation');

    const actualizarRequisitosEspecialista = () => {
        if (!passwordInput) return true;

        const pwd = passwordInput.value;
        const isLongEnough = pwd.length >= 8 && pwd.length <= 20;
        const hasLetters = /[a-zA-Z]/.test(pwd);
        const hasNumbers = /[0-9]/.test(pwd);
        const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);
        const passwordsMatch = pwd !== '' && pwd === passwordConfirmationInput?.value;
        const feedbackBox = document.getElementById('password-feedback-especialista');
        const strengthText = document.getElementById('especialista-strength-text');

        if (feedbackBox) feedbackBox.style.display = pwd.length > 0 ? 'block' : 'none';

        const updateRequirement = (elementId, isValid, text) => {
            const element = document.getElementById(elementId);
            if (!element) return;
            element.style.color = isValid ? '#198754' : '#dc3545';
            element.innerHTML = isValid ? `✓ ${text}` : `✗ ${text}`;
        };

        updateRequirement('especialista-length-req', isLongEnough, 'Entre 8 y 20 caracteres');
        updateRequirement('especialista-alpha-req', hasLetters && hasNumbers, 'Alfanumérica (letras y números)');
        updateRequirement('especialista-special-req', hasSpecial, 'Un carácter especial (@, $, !, %, etc.)');

        const isValid = isLongEnough && hasLetters && hasNumbers && hasSpecial;
        if (strengthText) {
            strengthText.textContent = isValid ? 'Estado: Contraseña Muy Segura' : 'Estado: Contraseña Poco Segura';
            strengthText.style.color = isValid ? '#198754' : '#dc3545';
        }

        if (passwordConfirmationInput && passwordConfirmationInput.value) {
            passwordConfirmationInput.style.border = passwordsMatch ? '' : '2px solid #dc3545';
        }
        return isValid && passwordsMatch;
    };

    if (passwordInput) passwordInput.addEventListener('input', actualizarRequisitosEspecialista);
    if (passwordConfirmationInput) passwordConfirmationInput.addEventListener('input', actualizarRequisitosEspecialista);

    if (form) {
        form.addEventListener('submit', function(e) {
            sincronizarEspecialidades();
            
            // ✅ FORZAR EL ORIGEN JUSTO ANTES DE ENVIAR
            const origenInput = document.getElementById('form-origen');
            if (origenInput) {
                // Si existe el buscador, estamos en la vista de terapeutas
                if (document.getElementById('buscador-terapeutas')) {
                    origenInput.value = 'terapeutas';
                } else {
                    // Si no, estamos en el dashboard
                    origenInput.value = 'dashboard';
                }
            }

            if (!validarContrasenas()) {
                e.preventDefault();
                return false;
            }
        });
    }

    document.querySelectorAll('.modal-zen, .modal-contenedor-alerta-critica').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.close();
            }
        });
    });

    renderizarEstrellas();
    initBuscadorTerapeutas();
});

function getBaseUrl() {
    let baseUrl = window.location.origin;
    if (window.location.pathname.includes('/public')) {
        baseUrl += window.location.pathname.substring(0, window.location.pathname.indexOf('/public') + 7);
    }
    return baseUrl;
}

//cambié la función del buscador para los terapeutas, para que el paginador pueda funcionar correctamente y no se rompa al filtrar, además de que ahora respeta el orden inicial de los terapeutas y los ordena correctamente según el criterio seleccionado. 
function initBuscadorTerapeutas() {
    const input       = document.getElementById('buscador-terapeutas');
    const selectOrden = document.getElementById('orden-terapeutas');
    const limpiarBtn  = document.getElementById('buscador-limpiar');
    const resultados  = document.getElementById('buscador-resultados');
    const sinResult   = document.getElementById('buscador-sin-resultados');
    const grid        = document.querySelector('.grid-terapeutas');

    const paginador   = document.getElementById('paginador-terapeutas');
    const btnPrev     = document.getElementById('pag-terapeutas-prev');
    const btnNext     = document.getElementById('pag-terapeutas-next');
    const numsCont    = document.getElementById('pag-terapeutas-numeros');
    const infoPag     = document.getElementById('pag-terapeutas-info');

    if (!grid) return;

    const tarjetas = Array.from(grid.querySelectorAll('.tarjeta-terapeuta'));
    if (tarjetas.length === 0) return;

    const ITEMS_POR_PAGINA = 12;
    let paginaActual = 1;

    function normalizar(texto) {
        return (texto || '')
            .toString()
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .trim();
    }

    const datosTarjetas = tarjetas.map(tarjeta => {
        const nombre = (tarjeta.dataset.nombre || tarjeta.querySelector('.terapeuta-nombre')?.textContent || '')
            .replace(/\(Yo\)/gi, '')
            .trim();
        const especialidades = tarjeta.dataset.especialidades || '';
        const promedio = parseFloat(tarjeta.dataset.promedio || 0);
        const esPropio = tarjeta.dataset.propio === '1' ? 1 : 0;
        const ordenInicial = parseInt(tarjeta.dataset.ordenInicial || 0, 10);
        const buscar = normalizar(`${nombre} ${especialidades}`);
        return { tarjeta, buscar, nombre, especialidades, promedio, esPropio, ordenInicial };
    });

    function obtenerOrdenadas(criterio) {
        const copia = [...datosTarjetas];

        copia.sort((a, b) => {
            if (criterio === 'defecto' && a.esPropio !== b.esPropio) {
                return b.esPropio - a.esPropio;
            }

            switch (criterio) {
                case 'alfabetico-asc':
                    return a.nombre.localeCompare(b.nombre, 'es', { sensitivity: 'base' });
                case 'alfabetico-desc':
                    return b.nombre.localeCompare(a.nombre, 'es', { sensitivity: 'base' });
                case 'rating-desc':
                    if (b.promedio !== a.promedio) return b.promedio - a.promedio;
                    return a.nombre.localeCompare(b.nombre, 'es', { sensitivity: 'base' });
                case 'defecto':
                default:
                    return a.ordenInicial - b.ordenInicial;
            }
        });

        return copia;
    }

    function escaparHTML(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function renderizarBotonesPagina(totalPaginas) {
        if (!numsCont) return;
        numsCont.innerHTML = '';

        for (let i = 1; i <= totalPaginas; i++) {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'pag-terapeutas-num' + (i === paginaActual ? ' is-active' : '');
            btn.textContent = i;
            btn.setAttribute('aria-label', `Ir a la página ${i}`);
            btn.addEventListener('click', () => {
                paginaActual = i;
                actualizarVista(false);
                grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
            numsCont.appendChild(btn);
        }
    }

    function actualizarVista(reiniciarPagina = true) {
        if (reiniciarPagina) {
            paginaActual = 1;
        }

        const termino = input ? input.value : '';
        const q = normalizar(termino);
        const criterio = selectOrden ? selectOrden.value : 'defecto';
        const filtroActivo = q !== '' || criterio !== 'defecto';

        const ordenadas = obtenerOrdenadas(criterio);

        ordenadas.forEach(({ tarjeta }) => {
            grid.appendChild(tarjeta);
        });

        const coincidencias = ordenadas.filter(({ buscar }) => q === '' || buscar.includes(q));
        const noCoinciden = ordenadas.filter(({ buscar }) => q !== '' && !buscar.includes(q));

        noCoinciden.forEach(({ tarjeta }) => {
            tarjeta.classList.add('is-hidden');
        });

        const totalCoincidencias = coincidencias.length;
        const totalPaginas = Math.max(1, Math.ceil(totalCoincidencias / ITEMS_POR_PAGINA));

        if (paginaActual > totalPaginas) paginaActual = totalPaginas;
        if (paginaActual < 1) paginaActual = 1;

        const inicio = (paginaActual - 1) * ITEMS_POR_PAGINA;
        const fin = inicio + ITEMS_POR_PAGINA;

        coincidencias.forEach(({ tarjeta }, idx) => {
            const enPagina = idx >= inicio && idx < fin;
            tarjeta.classList.toggle('is-hidden', !enPagina);
        });

        if (limpiarBtn) {
            limpiarBtn.hidden = !filtroActivo;
        }

        if (resultados) {
            if (!filtroActivo) {
                resultados.hidden = true;
                resultados.innerHTML = '';
            } else {
                resultados.hidden = false;
                const total = datosTarjetas.length;
                if (totalCoincidencias === 0) {
                    resultados.innerHTML = `Sin resultados para <strong>"${escaparHTML(termino)}"</strong>`;
                } else if (q !== '') {
                    resultados.innerHTML = `Mostrando <strong>${totalCoincidencias}</strong> de <strong>${total}</strong> especialistas para <strong>"${escaparHTML(termino)}"</strong>`;
                } else {
                    resultados.innerHTML = `Mostrando <strong>${totalCoincidencias}</strong> especialistas ordenados`;
                }
            }
        }

        if (sinResult) {
            sinResult.hidden = (totalCoincidencias !== 0);
        }

        if (paginador) {
            if (totalCoincidencias > ITEMS_POR_PAGINA) {
                paginador.hidden = false;
                if (infoPag) {
                    infoPag.textContent = `Página ${paginaActual} de ${totalPaginas}`;
                }
                if (btnPrev) {
                    btnPrev.disabled = (paginaActual <= 1);
                }
                if (btnNext) {
                    btnNext.disabled = (paginaActual >= totalPaginas);
                }
                renderizarBotonesPagina(totalPaginas);
            } else {
                paginador.hidden = true;
            }
        }
    }

    if (input) {
        input.addEventListener('input', () => actualizarVista(true));
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                input.value = '';
                actualizarVista(true);
                input.blur();
            }
        });
    }

    if (selectOrden) {
        selectOrden.addEventListener('change', () => actualizarVista(true));
    }

    if (limpiarBtn) {
        limpiarBtn.addEventListener('click', () => {
            if (input) input.value = '';
            if (selectOrden) selectOrden.value = 'defecto';
            actualizarVista(true);
            if (input) input.focus();
        });
    }

    if (btnPrev) {
        btnPrev.addEventListener('click', () => {
            if (paginaActual > 1) {
                paginaActual--;
                actualizarVista(false);
                grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    }

    if (btnNext) {
        btnNext.addEventListener('click', () => {
            const termino = input ? input.value : '';
            const q = normalizar(termino);
            const totalCoincidencias = datosTarjetas.filter(({ buscar }) => q === '' || buscar.includes(q)).length;
            const totalPaginas = Math.max(1, Math.ceil(totalCoincidencias / ITEMS_POR_PAGINA));

            if (paginaActual < totalPaginas) {
                paginaActual++;
                actualizarVista(false);
                grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    }

    actualizarVista(true);
}

function renderizarEstrellas() {
    document.querySelectorAll('.contenedor-estrellas').forEach(contenedor => {
        const promedio = parseFloat(contenedor.dataset.promedio || 0);
        const total = parseInt(contenedor.dataset.total || 0);

        const estrellasExistentes = contenedor.querySelectorAll('.estrellas span, .estrellas');
        if (estrellasExistentes.length > 0) return;

        const estrellasLlenas = Math.floor(promedio);
        const tieneMedia = (promedio - estrellasLlenas) >= 0.5;

        const spanEstrellas = document.createElement('span');
        spanEstrellas.className = 'estrellas';

        for (let i = 1; i <= 5; i++) {
            const star = document.createElement('span');
            if (i <= estrellasLlenas) {
                star.textContent = '★';
                star.style.color = 'var(--spa-gold)';
            } else if (i === estrellasLlenas + 1 && tieneMedia) {
                star.textContent = '★';
                star.style.color = 'var(--spa-gold)';
                star.style.opacity = '0.55';
            } else {
                star.textContent = '★';
                star.style.color = '#d1c7bd';
            }
            spanEstrellas.appendChild(star);
        }

        contenedor.innerHTML = '';
        contenedor.appendChild(spanEstrellas);

        const valor = document.createElement('span');
        valor.className = 'rating-valor';
        valor.textContent = promedio.toFixed(1);
        contenedor.appendChild(valor);

        const cantidad = document.createElement('span');
        cantidad.className = 'rating-cantidad';
        cantidad.textContent = `(${total})`;
        contenedor.appendChild(cantidad);
    });
}

window.verTerapeutaDetalle = function(id) {
    let tarjeta = document.querySelector(`.tarjeta-terapeuta[data-id="${id}"]`);
    if (!tarjeta) {
        const elemento = document.querySelector(`[data-id="${id}"]`);
        if (elemento) tarjeta = elemento.closest('.tarjeta-terapeuta');
    }
    if (!tarjeta) { alert('Terapeuta no encontrado'); return; }

    const nombre = tarjeta.querySelector('.terapeuta-nombre')?.textContent.trim() || 'Sin nombre';
    //Aquí estoy cambiando la forma en que se obtienen las especialidades para que sea más robusta y no dependa de un solo lugar, buscando primero en el dataset y luego en el contenido de la tarjeta. :D
    const especialidades = (
        tarjeta.dataset.especialidades ||
        tarjeta.querySelector('.tag-especialidad')?.textContent ||
        ''
    ).trim();
    const foto = tarjeta.querySelector('img')?.src || null;
    const telefono = tarjeta.querySelector('.terapeuta-telefono')?.textContent.trim() || 'No disponible';
    const email = tarjeta.querySelector('.terapeuta-email')?.textContent.trim() || 'No disponible';
    const descripcion = tarjeta.querySelector('.terapeuta-descripcion')?.textContent.trim() || 'Sin descripción';

    const modal = document.getElementById('modal-ver-terapeuta');
    if (modal) {
        document.getElementById('view-terapeuta-nombre').textContent = nombre;
        document.getElementById('view-terapeuta-telefono').textContent = telefono;
        document.getElementById('view-terapeuta-email').textContent = email;
        document.getElementById('view-terapeuta-descripcion').textContent = descripcion;

        //Con esto me aseguro de que las especialidades se muestren correctamente, incluso si no hay ninguna registrada, mostrando un mensaje amigable en ese caso. Att: Andrés
        const espContainer = document.getElementById('view-terapeuta-especialidades');
        if (especialidades && especialidades !== 'Sin especialidad' && especialidades !== 'Especialista en Bienestar') {
            const espArray = especialidades.split(',').map(e => e.trim()).filter(Boolean);
            espContainer.innerHTML = espArray.map(esp => `<span class="badge">${esp}</span>`).join('');
        } else {
            espContainer.innerHTML = '<span style="color: var(--gris-texto); font-size: 0.85rem;">Sin especialidades registradas</span>';
        }

        const fotoContainer = document.getElementById('view-terapeuta-foto');
        if (foto) {
            fotoContainer.innerHTML = `<img src="${foto}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
            fotoContainer.style.background = 'transparent';
        } else {
            const iniciales = nombre.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
            fotoContainer.innerHTML = iniciales;
            fotoContainer.style.background = '#e8e0d6';
            fotoContainer.style.display = 'flex';
            fotoContainer.style.alignItems = 'center';
            fotoContainer.style.justifyContent = 'center';
            fotoContainer.style.fontSize = '1.8rem';
            fotoContainer.style.fontWeight = '600';
            fotoContainer.style.color = 'var(--color-marron-oscuro)';
        }

        const accionesAdmin = document.getElementById('view-acciones-admin');
        if (accionesAdmin) {
            accionesAdmin.innerHTML = `
                <button type="button" class="btn-zen" style="background:white; border:1px solid #cbd5e1; color:#475569;" onclick="document.getElementById('modal-ver-terapeuta').close(); editarTerapeuta(${id});">Editar</button>
                <button type="button" class="btn-zen btn-baja" onclick="document.getElementById('modal-ver-terapeuta').close(); eliminarTerapeuta(${id});">Dar de Baja</button>
            `;
        }
        modal.showModal();
    }
};

window.abrirModalAgregar = function() {
    const modal = document.getElementById('modal-terapeuta');
    const form = document.getElementById('form-terapeuta');
    if (!modal || !form) return;

    form.reset();
    form.action = `${getBaseUrl()}/admin/crear-trabajador`;
    
    document.getElementById('terapeuta_method').value = 'POST';

    const origenInput = document.getElementById('form-origen');
    if (origenInput) {
        origenInput.value = document.getElementById('buscador-terapeutas') ? 'terapeutas' : 'dashboard';
    }

    document.getElementById('modal-titulo').textContent = 'Registrar Nuevo Especialista';

    const avatar = document.getElementById('previsualizacion-avatar-terapeuta');
    if (avatar) {
        avatar.innerHTML = 'TF';
        avatar.style.background = '#e8e0d6';
        avatar.style.display = 'flex';
        avatar.style.alignItems = 'center';
        avatar.style.justifyContent = 'center';
        avatar.style.fontSize = '1.3rem';
        avatar.style.fontWeight = '600';
        avatar.style.color = 'var(--color-marron-oscuro)';
    }

    const wrapper = document.getElementById('wrapper-especialidades-lista');
    if (wrapper) {
        wrapper.innerHTML = `
            <div class="fila-especialidad">
                <input type="text" class="input-especialidad-item" placeholder="Ej. Rejuvenecimiento Facial" required>
                <button type="button" class="btn-añadir-especialidad" onclick="agregarCampoEspecialidad('')">+</button>
            </div>
        `;
    }

    document.getElementById('campo-password').style.display = 'block';
    document.getElementById('password').required = true;
    document.getElementById('password').value = '';
    document.getElementById('password_confirmation').required = true;
    document.getElementById('password_confirmation').value = '';

    modal.showModal();
};

window.editarTerapeuta = function(id) {
    const modal = document.getElementById('modal-terapeuta');
    const form = document.getElementById('form-terapeuta');
    if (!modal || !form) return;

    let tarjeta = document.querySelector(`.tarjeta-terapeuta[data-id="${id}"]`);
    if (!tarjeta) tarjeta = document.querySelector(`.tarjeta-fila[data-id="${id}"]`);

    form.action = `${getBaseUrl()}/admin/trabajador/${id}`;
    document.getElementById('terapeuta_method').value = 'PUT';

    const origenInput = document.getElementById('form-origen');
    if (origenInput) {
        origenInput.value = 'terapeutas';
    }

    document.getElementById('modal-titulo').textContent = 'Editar Información del Especialista';
    document.getElementById('campo-password').style.display = 'none';
    document.getElementById('password').required = false;
    document.getElementById('password').value = '';
    document.getElementById('password_confirmation').required = false;
    document.getElementById('password_confirmation').value = '';

    let nombre = '', email = '', telefono = '', descripcion = '', especialidades = '';

    if (tarjeta) {
        nombre = tarjeta.querySelector('.terapeuta-nombre')?.textContent.trim() || '';
        email = tarjeta.querySelector('.terapeuta-email')?.textContent.trim() || '';
        telefono = tarjeta.querySelector('.terapeuta-telefono')?.textContent.replace('Teléfono:', '').trim() || '';
        descripcion = tarjeta.querySelector('.terapeuta-descripcion')?.textContent.trim() || '';
        especialidades = tarjeta.dataset.especialidades || '';
    }

    document.getElementById('nombre').value = nombre;
    document.getElementById('email').value = email;
    document.getElementById('telefono').value = telefono;
    document.getElementById('descripcion').value = descripcion;

    const wrapper = document.getElementById('wrapper-especialidades-lista');
    if (wrapper) {
        wrapper.innerHTML = '';
        const espData = especialidades ? especialidades.split(',') : [];
        if (espData.length === 0 || (espData.length === 1 && espData[0] === '')) {
            wrapper.innerHTML = `<div class="fila-especialidad"><input type="text" class="input-especialidad-item" placeholder="Ej. Rejuvenecimiento Facial" required><button type="button" class="btn-añadir-especialidad" onclick="agregarCampoEspecialidad('')">+</button></div>`;
        } else {
            espData.forEach((esp, index) => {
                const div = document.createElement('div');
                div.className = 'fila-especialidad';
                div.innerHTML = `
                    <input type="text" class="input-especialidad-item" value="${esp.trim()}" required>
                    ${index === 0 ? `<button type="button" class="btn-añadir-especialidad" onclick="agregarCampoEspecialidad('')">+</button>` : `<button type="button" class="btn-remover-especialidad" onclick="this.parentElement.remove()">×</button>`}
                `;
                wrapper.appendChild(div);
            });
        }
    }
    modal.showModal();
};

window.editarTerapeutaDesdeDashboard = function(id, nombre, email, telefono, especialidades, descripcion) {
    const modal = document.getElementById('modal-terapeuta');
    const form = document.getElementById('form-terapeuta');
    if (!modal || !form) return;

    form.action = `${getBaseUrl()}/admin/trabajador/${id}`;
    document.getElementById('terapeuta_method').value = 'PUT';
    document.getElementById('modal-titulo').textContent = 'Editar Información del Especialista';

    const origenInput = document.getElementById('form-origen');
    if (origenInput) origenInput.value = 'dashboard';

    document.getElementById('campo-password').style.display = 'none';
    document.getElementById('password').required = false;
    document.getElementById('password').value = '';
    document.getElementById('password_confirmation').required = false;
    document.getElementById('password_confirmation').value = '';

    document.getElementById('nombre').value = nombre || '';
    document.getElementById('email').value = email || '';
    document.getElementById('telefono').value = telefono || '';
    document.getElementById('descripcion').value = descripcion || '';

    const wrapper = document.getElementById('wrapper-especialidades-lista');
    wrapper.innerHTML = '';
    const espData = especialidades ? especialidades.split(',') : [];
    if (espData.length === 0 || (espData.length === 1 && espData[0] === '')) {
        wrapper.innerHTML = `<div class="fila-especialidad"><input type="text" class="input-especialidad-item" placeholder="Ej. Rejuvenecimiento Facial" required><button type="button" class="btn-añadir-especialidad" onclick="agregarCampoEspecialidad('')">+</button></div>`;
    } else {
        espData.forEach((esp, index) => {
            const div = document.createElement('div');
            div.className = 'fila-especialidad';
            div.innerHTML = `
                <input type="text" class="input-especialidad-item" value="${esp.trim()}" required>
                ${index === 0 ? `<button type="button" class="btn-añadir-especialidad" onclick="agregarCampoEspecialidad('')">+</button>` : `<button type="button" class="btn-remover-especialidad" onclick="this.parentElement.remove()">×</button>`}
            `;
            wrapper.appendChild(div);
        });
    }
    modal.showModal();
};

/**
 * Eliminar especialista
 * Usa fetch para mostrar SweetAlert y luego recargar la página.
 */
window.eliminarTerapeuta = function(id) {
    const modal = document.getElementById('modal-confirmacion-custom');
    
    // Fallback por si el modal de confirmación no existe en la vista actual
    if (!modal) {
        if (confirm('¿Estás seguro de eliminar este especialista?')) {
            const token = document.querySelector('input[name="_token"]')?.value || '';
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `${getBaseUrl()}/admin/usuario/${id}`;
            form.innerHTML = `<input type="hidden" name="_token" value="${token}"><input type="hidden" name="_method" value="DELETE">`;
            document.body.appendChild(form);
            form.submit();
        }
        return;
    }

    let nombreTerapeuta = '';
    const tarjeta = document.querySelector(`.tarjeta-terapeuta[data-id="${id}"], .tarjeta-fila[data-id="${id}"], .dash-user-row[data-id="${id}"]`);
    if (tarjeta) {
        nombreTerapeuta = tarjeta.querySelector('.terapeuta-nombre')?.textContent.trim() || 
                          tarjeta.querySelector('.info-usuario h4')?.textContent.trim() || 
                          tarjeta.querySelector('.dash-user-name h4')?.textContent.trim() || '';
    }

    const nombreTexto = nombreTerapeuta ? `"${nombreTerapeuta.toUpperCase()}"` : 'este especialista';
    document.getElementById('confirm-alerta-titulo').textContent = '¿Remover especialista del equipo?';
    document.getElementById('confirm-alerta-mensaje').textContent = `¿Estás seguro de eliminar permanentemente a ${nombreTexto} del sistema? Esta operación no se puede deshacer.`;

    modal.showModal();

    const btnAceptar = document.getElementById('btn-confirm-aceptar');
    const nuevoAceptar = btnAceptar.cloneNode(true);
    btnAceptar.parentNode.replaceChild(nuevoAceptar, btnAceptar);

    nuevoAceptar.onclick = function() {
        modal.close();
        
        const token = document.querySelector('input[name="_token"]')?.value || '';
        const formData = new FormData();
        formData.append('_token', token);
        formData.append('_method', 'DELETE');

        // Enviamos la petición con fetch
        fetch(`${getBaseUrl()}/admin/usuario/${id}`, {
            method: 'POST', // POST simulando DELETE por el _method
            headers: {
                'X-CSRF-TOKEN': token,
                'Accept': 'application/json'
            },
            body: formData
        })
        .then(response => {
            if (!response.ok) throw new Error('Error al eliminar');
            return response.json().catch(() => ({}));
        })
        .then(() => {
            // Mostramos el SweetAlert de éxito
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    icon: 'success',
                    title: '¡Excelente!',
                    text: 'Especialista eliminado correctamente del sistema.',
                    confirmButtonColor: '#8b5e3c',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                }).then(() => {
                    window.location.reload();
                });
            } else {
                window.location.reload();
            }
        })
        .catch(error => {
            console.error(error);
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'No se pudo eliminar al especialista. Intenta de nuevo.',
                    confirmButtonColor: '#c53030'
                });
            } else {
                alert('No se pudo eliminar al especialista.');
            }
        });
    };

    document.getElementById('btn-confirm-cancelar').onclick = function() { modal.close(); };
};

window.agregarCampoEspecialidad = function(valor = '') {
    const wrapper = document.getElementById('wrapper-especialidades-lista');
    if (!wrapper) return;
    const div = document.createElement('div');
    div.className = 'fila-especialidad';
    div.innerHTML = `<input type="text" class="input-especialidad-item" value="${valor}" placeholder="Ej. Rejuvenecimiento Facial" required><button type="button" class="btn-remover-especialidad" onclick="this.parentElement.remove()">×</button>`;
    wrapper.appendChild(div);
};

window.sincronizarEspecialidades = function() {
    const inputs = document.querySelectorAll('.input-especialidad-item');
    const lista = [];
    inputs.forEach(input => {
        const val = input.value.trim();
        if (val) lista.push(val);
    });
    const hidden = document.getElementById('especialidades_hidden');
    if (hidden) hidden.value = lista.join(',');
};
//Aquí estoy modificando las alertas para que ya no se vean feas, agregué una función para mostrar alertas de manera más bonita y amigable, usando SweetAlert si está disponible, o un alert normal como fallback. :D att. Andrés
window.mostrarAlertaTerapeuta = function(titulo, mensaje, campoEnfocar = null) {
    const modalTerapeuta = document.getElementById('modal-terapeuta');
    const estabaAbierto = modalTerapeuta && modalTerapeuta.open;

    if (typeof Swal !== 'undefined') {
        if (estabaAbierto) modalTerapeuta.close();

        Swal.fire({
            icon: 'warning',
            title: titulo,
            text: mensaje,
            confirmButtonText: 'ACEPTAR',
            customClass: {
                popup: 'tbr-dash-popup',
                title: 'tbr-dash-title',
                htmlContainer: 'tbr-dash-text',
                confirmButton: 'tbr-dash-btn'
            },
            buttonsStyling: false
        }).then(() => {
            if (estabaAbierto) modalTerapeuta.showModal();
            if (campoEnfocar) campoEnfocar.focus();
        });
    } else {
        alert(mensaje);
        if (campoEnfocar) campoEnfocar.focus();
    }
};

window.validarContrasenas = function() {
    const pass = document.getElementById('password');
    const confirm = document.getElementById('password_confirmation');
    const emailInput = document.getElementById('email');
    
    const errorPassDiv = document.getElementById('error-password');
    const errorEmailDiv = document.getElementById('error-email');

    // Limpiar errores previos
    if (pass) pass.classList.remove('input-error');
    if (confirm) confirm.classList.remove('input-error');
    if (emailInput) emailInput.classList.remove('input-error');
    
    if (errorPassDiv) {
        errorPassDiv.style.display = 'none';
        errorPassDiv.textContent = '';
    }
    if (errorEmailDiv) {
        errorEmailDiv.style.display = 'none';
        errorEmailDiv.textContent = '';
    }

    // 1. Validación de formato básico de correo
    if (emailInput && emailInput.value.trim() !== '') {
        const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regexEmail.test(emailInput.value.trim())) {
            emailInput.classList.add('input-error');
            window.mostrarAlertaTerapeuta(
                'Correo inválido',
                'Ingresa una dirección de correo electrónico válida.',
                emailInput
            );
            return false;
        }
    }

    // Si no hay campos de contraseña obligatorios (ej. modo edición)
    if (!pass || !confirm) return true;
    if (pass.value === '' && confirm.value === '') return true;

    // 2. Validación completa de contraseña
    const hasLetters = /[a-zA-Z]/.test(pass.value);
    const hasNumbers = /[0-9]/.test(pass.value);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pass.value);

    if (pass.value.length > 0 && (pass.value.length < 8 || pass.value.length > 20)) {
        pass.classList.add('input-error');
        window.mostrarAlertaTerapeuta(
            'Atención',
            'Tu contraseña no cumple con los criterios de seguridad',
            pass
        );
        return false;
    }

    if (pass.value.length > 0 && (!hasLetters || !hasNumbers || !hasSpecial)) {
        pass.classList.add('input-error');
        window.mostrarAlertaTerapeuta(
            'Atención',
            'Tu contraseña no cumple con los criterios de seguridad',
            pass
        );
        return false;
    }

    // 3. Validación de coincidencia de contraseñas
    if (pass.value !== confirm.value) {
        pass.classList.add('input-error');
        confirm.classList.add('input-error');
        window.mostrarAlertaTerapeuta(
            'Atención',
            'Tus contraseñas no coinciden',
            confirm
        );
        return false;
    }

    return true;
};

window.alternarVisibilidad = function(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const svg = btn.querySelector('.svg-ojo');
    if (!svg) return;
    if (input.type === 'password') {
        input.type = 'text';
        svg.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" />`;
    } else {
        input.type = 'password';
        svg.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />`;
    }
};

window.previsualizarImagen = function(input, previewId) {
    const preview = document.getElementById(previewId);
    if (!preview || !input.files || !input.files[0]) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        preview.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
        preview.style.background = 'transparent';
        preview.style.display = 'flex';
        preview.style.alignItems = 'center';
        preview.style.justifyContent = 'center';
    };
    reader.readAsDataURL(input.files[0]);
};

window.cerrarModal = function() {
    document.querySelectorAll('dialog[open]').forEach(d => d.close());
};

if (typeof window.Syncro === 'undefined') window.Syncro = {};

window.Syncro.openEsp = function() { if (typeof window.abrirModalAgregar === 'function') window.abrirModalAgregar(); };
window.Syncro.editEsp = function(id, nombre, email, telefono, especialidades, descripcion) {
    if (nombre !== undefined) {
        if (typeof window.editarTerapeutaDesdeDashboard === 'function') window.editarTerapeutaDesdeDashboard(id, nombre, email, telefono, especialidades, descripcion);
    } else {
        if (typeof window.editarTerapeuta === 'function') window.editarTerapeuta(id);
    }
};
window.Syncro.delEsp = function(id) { if (typeof window.eliminarTerapeuta === 'function') window.eliminarTerapeuta(id); };
// ============================================
// VISOR DE FOTO COMPLETA (LIGHTBOX)
// ============================================
window.abrirVisorFoto = function(url, nombre) {
    const visor = document.getElementById('visor-foto-terapeuta');
    const imagen = document.getElementById('visor-foto-imagen');
    const texto = document.getElementById('visor-foto-nombre');
    
    if (visor && imagen) {
        imagen.src = url;
        texto.textContent = nombre;
        visor.showModal();
    }
};

// Permitir cerrar con la tecla Escape
document.addEventListener('DOMContentLoaded', () => {
    const visor = document.getElementById('visor-foto-terapeuta');
    if (visor) {
        visor.addEventListener('cancel', (e) => {
            e.preventDefault();
            visor.close();
        });
    }
});
// ============================================
// MODAL DE RESEÑAS - CONTROLADOR CON PAGINACIÓN
// ============================================
let resenasActuales = [];
let paginaActualResenas = 1;
const LIMITE_RESENAS_POR_PAGINA = 3; // 👈 Aquí puedes cambiar cuántas reseñas se ven por página

window.verResenasTerapeuta = function(btn) {
    if (typeof event !== 'undefined' && event) {
        event.stopPropagation();
        event.preventDefault();
    }

    const modal = document.getElementById('modal-resenas');
    const titulo = document.getElementById('resenas-titulo-terapeuta');
    
    if (!modal) return;

    const nombre = btn.dataset.nombre || 'Especialista';
    try {
        resenasActuales = JSON.parse(btn.dataset.resenas || '[]');
    } catch (e) {
        console.error("Error al parsear las reseñas", e);
        resenasActuales = [];
    }
    
    titulo.textContent = `Reseñas de ${nombre}`;
    paginaActualResenas = 1; // Reiniciar a la primera página
    renderizarPaginaResenas();

    // Forzar visualización centrada con flex
    modal.style.setProperty('display', 'flex', 'important');
    modal.classList.add('is-open');
};

window.renderizarPaginaResenas = function() {
    const contenedor = document.getElementById('lista-resenas');
    if (!contenedor) return;
    contenedor.textContent = '';

    if (resenasActuales.length === 0) {
        const vacio = document.createElement('div');
        vacio.style.cssText = 'text-align: center; padding: 2.5rem 1rem; color: #8c7a6b;';

        const mensaje = document.createElement('p');
        mensaje.style.cssText = "font-family: 'Cormorant Garamond', serif; font-size: 1.2rem; margin: 0;";
        mensaje.textContent = 'Este especialista aún no cuenta con opiniones registradas.';

        const invitacion = document.createElement('small');
        invitacion.style.cssText = 'font-size: 0.8rem; color: #a89a8c; display: block; margin-top: 0.4rem;';
        invitacion.textContent = '¡Sé el primero en calificar su servicio!';

        vacio.appendChild(mensaje);
        vacio.appendChild(invitacion);
        contenedor.appendChild(vacio);
        return;
    }

    // Calcular índices para el slice
    const totalResenas = resenasActuales.length;
    const totalPaginas = Math.ceil(totalResenas / LIMITE_RESENAS_POR_PAGINA);
    
    if (paginaActualResenas > totalPaginas) paginaActualResenas = totalPaginas;
    if (paginaActualResenas < 1) paginaActualResenas = 1;

    const inicio = (paginaActualResenas - 1) * LIMITE_RESENAS_POR_PAGINA;
    const fin = inicio + LIMITE_RESENAS_POR_PAGINA;
    const resenasPagina = resenasActuales.slice(inicio, fin);

    // Renderizar las reseñas de la página actual
    resenasPagina.forEach(resena => {
        const puntuacion = parseInt(resena.puntuacion || 0);
        const tarjeta = document.createElement('div');
        tarjeta.className = 'resena-item-card';
        tarjeta.style.cssText = 'border-bottom: 1px solid #efe9e1; padding-bottom: 1.25rem;';

        const cabecera = document.createElement('div');
        cabecera.style.cssText = 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;';

        const estrellas = document.createElement('div');
        estrellas.style.cssText = 'color: #f5b301; font-size: 0.95rem; letter-spacing: 2px;';
        for (let i = 1; i <= 5; i++) {
            if (i <= puntuacion) {
                estrellas.appendChild(document.createTextNode('★'));
            } else {
                const estrella = document.createElement('span');
                estrella.style.color = '#d1c7bd';
                estrella.textContent = '★';
                estrellas.appendChild(estrella);
            }
        }

        const fecha = document.createElement('span');
        fecha.style.cssText = "font-family: 'Inter', sans-serif; font-size: 0.72rem; color: #a89a8c; font-weight: 500;";
        fecha.textContent = resena.fecha ?? '';
        cabecera.appendChild(estrellas);
        cabecera.appendChild(fecha);

        const comentario = document.createElement('p');
        comentario.style.cssText = "font-family: 'Cormorant Garamond', serif; font-size: 1.15rem; font-style: italic; color: #3d2c1e; margin: 0 0 0.5rem 0; line-height: 1.4;";
        comentario.textContent = `"${resena.comentario ?? ''}"`;

        const cliente = document.createElement('span');
        cliente.style.cssText = "font-family: 'Inter', sans-serif; font-size: 0.75rem; font-weight: 700; color: #8b5e3c; text-transform: uppercase; letter-spacing: 0.5px;";
        cliente.textContent = resena.cliente ?? '';

        tarjeta.appendChild(cabecera);
        tarjeta.appendChild(comentario);
        tarjeta.appendChild(cliente);
        contenedor.appendChild(tarjeta);
    });

    // Agregar barra de paginación si hay más de una página
    if (totalPaginas > 1) {
        const paginador = document.createElement('div');
        paginador.className = 'modal-paginador-container';
        paginador.style.cssText = 'display: flex; align-items: center; justify-content: space-between; padding-top: 1rem; border-top: 1px solid #efe9e1; margin-top: auto;';

        const anterior = document.createElement('button');
        anterior.type = 'button';
        anterior.className = 'btn-paginador-modal';
        anterior.disabled = paginaActualResenas === 1;
        anterior.style.cssText = `padding: 0.4rem 0.9rem; border-radius: 6px; border: 1px solid #e8e2dd; background: ${paginaActualResenas === 1 ? '#f5efe8' : '#ffffff'}; color: ${paginaActualResenas === 1 ? '#a89a8c' : '#4a3b32'}; font-size: 0.75rem; font-weight: 600; cursor: ${paginaActualResenas === 1 ? 'not-allowed' : 'pointer'};`;
        anterior.textContent = '← Anterior';
        anterior.addEventListener('click', () => window.cambiarPaginaResenas(-1));

        const pagina = document.createElement('span');
        pagina.style.cssText = "font-family: 'Inter', sans-serif; font-size: 0.75rem; font-weight: 600; color: #8c7a6b; text-transform: uppercase; letter-spacing: 0.5px;";
        pagina.textContent = `Página ${paginaActualResenas} de ${totalPaginas}`;

        const siguiente = document.createElement('button');
        siguiente.type = 'button';
        siguiente.className = 'btn-paginador-modal';
        siguiente.disabled = paginaActualResenas === totalPaginas;
        siguiente.style.cssText = `padding: 0.4rem 0.9rem; border-radius: 6px; border: 1px solid #e8e2dd; background: ${paginaActualResenas === totalPaginas ? '#f5efe8' : '#ffffff'}; color: ${paginaActualResenas === totalPaginas ? '#a89a8c' : '#4a3b32'}; font-size: 0.75rem; font-weight: 600; cursor: ${paginaActualResenas === totalPaginas ? 'not-allowed' : 'pointer'};`;
        siguiente.textContent = 'Siguiente →';
        siguiente.addEventListener('click', () => window.cambiarPaginaResenas(1));

        paginador.appendChild(anterior);
        paginador.appendChild(pagina);
        paginador.appendChild(siguiente);
        contenedor.appendChild(paginador);
    }
};

window.cambiarPaginaResenas = function(direccion) {
    const totalPaginas = Math.ceil(resenasActuales.length / LIMITE_RESENAS_POR_PAGINA);
    paginaActualResenas += direccion;
    if (paginaActualResenas < 1) paginaActualResenas = 1;
    if (paginaActualResenas > totalPaginas) paginaActualResenas = totalPaginas;
    renderizarPaginaResenas();
};

window.cerrarModalResenas = function() {
    const modal = document.getElementById('modal-resenas');
    if (modal) {
        modal.style.setProperty('display', 'none', 'important');
        modal.classList.remove('is-open');
    }
};