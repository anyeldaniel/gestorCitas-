/**
 * auth.js — The Beauty Room
 * Toda la lógica de la vista de autenticación (login + registro + reset + forgot).
 */

// =============================================
// FUNCIÓN GLOBAL: ojito para ver/ocultar contraseña
// (Exactamente como tu código original)
// =============================================
function togglePassword(inputId, iconElement) {
    const input = document.getElementById(inputId);
    if (!input) return;

    if (input.type === 'password') {
        input.type = 'text';
        // Cambiamos el ícono a ojo tachado y aplicamos el color oscuro
        if (iconElement) {
            iconElement.innerHTML = '<i data-lucide="eye-off"></i>';
            iconElement.style.filter = 'grayscale(0) opacity(1)';
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    } else {
        input.type = 'password';
        // Volvemos al ícono de ojo normal y lo atenuamos
        if (iconElement) {
            iconElement.innerHTML = '<i data-lucide="eye"></i>';
            iconElement.style.filter = 'grayscale(100%) opacity(0.5)';
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    }
}

document.addEventListener('DOMContentLoaded', function () {

    // =============================================
    // 0. INICIALIZAR ÍCONOS LUCIDE
    // =============================================
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Función auxiliar para alertas para errores en contraseña
    const mostrarAlertaTBR = (titulo, mensaje, campoEnfocar = null) => {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'warning',
                title: titulo,
                text: mensaje,
                confirmButtonText: 'ACEPTAR',
                customClass: {
                    popup: 'tbr-alert-popup',
                    title: 'tbr-alert-title',
                    htmlContainer: 'tbr-alert-text',
                    confirmButton: 'tbr-alert-btn'
                },
                buttonsStyling: false
            }).then(() => {
                if (campoEnfocar) campoEnfocar.focus();
            });
        } else {
            alert(mensaje);
            if (campoEnfocar) campoEnfocar.focus();
        }
    };

    // =============================================
    // 1. TOGGLE ENTRE PANEL LOGIN / REGISTRO
    // =============================================
    const contenedor = document.getElementById('contenedor-principal');
    const btnPanelRegistro = document.getElementById('btn-panel-registro');
    const btnPanelLogin = document.getElementById('btn-panel-login');
    const btnIrRegistro = document.getElementById('btn-ir-registro');
    const btnIrLogin = document.getElementById('btn-ir-login');

    const btnMovilARegistro = document.getElementById('btn-movil-a-registro');
    const btnMovilALogin = document.getElementById('btn-movil-a-login');

    if (btnPanelRegistro) btnPanelRegistro.addEventListener('click', () => contenedor.classList.add('activo'));
    if (btnIrRegistro) btnIrRegistro.addEventListener('click', () => contenedor.classList.add('activo'));
    if (btnMovilARegistro) {
        btnMovilARegistro.addEventListener('click', (e) => {
            e.preventDefault();
            contenedor.classList.add('activo');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (btnPanelLogin) btnPanelLogin.addEventListener('click', () => contenedor.classList.remove('activo'));
    if (btnIrLogin) btnIrLogin.addEventListener('click', () => contenedor.classList.remove('activo'));
    if (btnMovilALogin) {
        btnMovilALogin.addEventListener('click', (e) => {
            e.preventDefault();
            contenedor.classList.remove('activo');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }


    // =============================================
    // 2. OJITO (listener adicional, por si algún botón no usa onclick)
    // =============================================
    document.querySelectorAll('.btn-ver-clave').forEach(boton => {
        boton.addEventListener('click', function () {
            const input = this.previousElementSibling;
            if (!input) return;

            if (input.type === 'password') {
                input.type = 'text';
                this.innerHTML = '<i data-lucide="eye-off"></i>';
                this.style.filter = 'grayscale(0) opacity(1)';
                if (typeof lucide !== 'undefined') lucide.createIcons();
            } else {
                input.type = 'password';
                this.innerHTML = '<i data-lucide="eye"></i>';
                this.style.filter = 'grayscale(100%) opacity(0.5)';
                if (typeof lucide !== 'undefined') lucide.createIcons();
            }
        });
    });


    // =============================================
    // 3. VALIDACIÓN DE CONTRASEÑA EN VIVO (REGISTRO)
    // =============================================
    const passwordInput = document.getElementById('password_reg');
    const emailInput = document.getElementById('email_reg');
    const registerForm = document.getElementById('form-registro');

    let isPasswordValid = false;

    if (passwordInput) {
        passwordInput.addEventListener('input', function () {
            const pwd = passwordInput.value;

            const reqLength = document.getElementById('length-req');
            const reqAlpha = document.getElementById('alpha-req');
            const reqSpecial = document.getElementById('special-req');
            const strengthText = document.getElementById('strength-text');
            const feedbackBox = document.getElementById('password-feedback');

            if (feedbackBox) feedbackBox.style.display = pwd.length > 0 ? 'block' : 'none';

            const hasLetters = /[a-zA-Z]/.test(pwd);
            const hasNumbers = /[0-9]/.test(pwd);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);
            const isLongEnough = pwd.length >= 8;

            const updateRequirement = (element, isValid, text) => {
                if (!element) return;
                element.style.color = isValid ? '#198754' : '#dc3545';
                element.innerHTML = isValid ? `✓ ${text}` : `✗ ${text}`;
            };

            updateRequirement(reqLength, isLongEnough, 'Mínimo 8 caracteres');
            updateRequirement(reqAlpha, (hasLetters && hasNumbers), 'Alfanumérica (letras y números)');
            updateRequirement(reqSpecial, hasSpecial, 'Un carácter especial (@, $, !, %, etc.)');

            if (isLongEnough && hasLetters && hasNumbers && hasSpecial) {
                isPasswordValid = true;
                if (strengthText) {
                    strengthText.textContent = 'Estado: Contraseña Muy Segura';
                    strengthText.style.color = '#198754';
                }
            } else {
                isPasswordValid = false;
                if (strengthText) {
                    strengthText.textContent = 'Estado: Contraseña Poco Segura';
                    strengthText.style.color = '#dc3545';
                }
            }
        });
    }

    // --- 4. VALIDACIÓN AL ENVIAR EL REGISTRO ---
    if (registerForm) {
        registerForm.addEventListener('submit', function (event) {
            const emailValue = emailInput ? emailInput.value.trim() : '';
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (emailValue === '' || !emailRegex.test(emailValue)) {
                event.preventDefault();
                if (emailInput) emailInput.style.border = '2px solid #dc3545';
                mostrarAlertaTBR('Correo inválido', 'Por favor ingresa un correo electrónico válido.', emailInput);
                return;
            } else if (emailInput) {
                emailInput.style.border = '';
            }

            if (!isPasswordValid) {
                event.preventDefault();
                mostrarAlertaTBR(
                    'Atención',
                    'Tu contraseña no cumple con los criterios de seguridad',
                    passwordInput
                );
                return; 
            }

            const regConfirmInput = registerForm.querySelector('#confirm-password, input[name="confirmPassword"]');
                if (regConfirmInput && regConfirmInput.value !== passwordInput.value) {
                    event.preventDefault();
                    mostrarAlertaTBR(
                        'Atención',
                        'Tus contraseñas no coinciden',
                        regConfirmInput
                    );
                    return;
                }
        });
    }
    
    // =============================================
    // 5. SWEETALERT2
    // =============================================
    if (typeof Swal !== 'undefined') {

        // 5a. Loading al enviar el registro
        if (registerForm) {
            registerForm.addEventListener('submit', function () {
                if (event.defaultPrevented) return;

                setTimeout(() => {
                    Swal.fire({
                        title: 'Creando tu cuenta...',
                        text: 'Estamos registrando tu perfil en The Beauty Room.',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        didOpen: () => { Swal.showLoading(); }
                    });
                }, 10);
            });
        }

        // 5b. Datos que vienen del Blade (sin lógica en el Blade)
        const config = document.getElementById('auth-config');

        if (config) {
            // Alerta de éxito tras registro
            if (config.dataset.success === '1') {
                Swal.fire({
                    icon: 'success',
                    title: '¡Cuenta creada con éxito!',
                    text: 'Ya eres parte de The Beauty Room. Por favor, inicia sesión con tus datos para comenzar a agendar tus citas.',
                    confirmButtonText: 'Iniciar Sesión',
                    confirmButtonColor: '#5A6B5D',
                    background: '#FFFFFF',
                    color: '#2C352D'
                });
            }

            // Mantener el panel en Registro si hay errores de validación
            if (config.dataset.forceRegister === '1' && contenedor) {
                contenedor.classList.add('activo');
            }
        }

        // 5c. NUEVA ALERTA: Recuperación de contraseña (Forgot Password)
        const tarjetaForgot = document.querySelector('.tarjeta-unica');
        
        if (tarjetaForgot) {
            if (tarjetaForgot.dataset.sessionStatus && tarjetaForgot.dataset.sessionStatus.trim() !== '') {
                Swal.fire({
                    icon: 'success',
                    title: '¡Enlace enviado!',
                    text: tarjetaForgot.dataset.sessionStatus,
                    confirmButtonText: 'Entendido',
                    confirmButtonColor: '#2C221D',
                    background: '#F8F6F4',
                    color: '#2C221D'
                });
            }
        }
    }
            // 5d. Contraseña restablecida con éxito (Reset Password)
        const resetConfig = document.getElementById('reset-config');
        
        if (resetConfig && resetConfig.dataset.success === '1') {
            Swal.fire({
                icon: 'success',
                title: '¡Clave actualizada!',
                text: resetConfig.dataset.message || 'Tu nueva clave se creó con éxito. Serás redirigido al login.',
                confirmButtonText: 'Ir al Login',
                confirmButtonColor: '#2C221D',
                background: '#F8F6F4',
                color: '#2C221D',
                allowOutsideClick: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "{{ route('login.view') }}"; 
                }
            });
        }

    // =============================================
    // 6. LÓGICA DE RESET PASSWORD (ESTADO DE LA NUEVA CLAVE)
    // =============================================
    const resetPasswordInput = document.getElementById('password');
    const resetPasswordConfirmationInput = document.getElementById('password_confirmation');
    const resetPasswordForm = document.getElementById('reset-password-form');
    let isResetPasswordValid = false;
    
    if (resetPasswordInput && document.getElementById('length-req')) {
        resetPasswordInput.addEventListener('input', function() {
            const pwd = this.value;

            const reqLength = document.getElementById('length-req');
            const reqAlpha = document.getElementById('alpha-req');
            const reqSpecial = document.getElementById('special-req');
            const strengthText = document.getElementById('strength-text');
            const feedbackBox = document.getElementById('password-feedback');

            if (feedbackBox) feedbackBox.style.display = pwd.length > 0 ? 'block' : 'none';

            const hasLetters = /[a-zA-Z]/.test(pwd);
            const hasNumbers = /[0-9]/.test(pwd);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);
            const isLengthValid = pwd.length >= 8 && pwd.length <= 20;

            const updateRequirement = (element, isValid, text) => {
                if (!element) return;
                element.style.color = isValid ? '#198754' : '#dc3545';
                element.innerHTML = isValid ? `✓ ${text}` : `✗ ${text}`;
            };

            updateRequirement(reqLength, isLengthValid, 'Entre 8 y 20 caracteres');
            updateRequirement(reqAlpha, (hasLetters && hasNumbers), 'Alfanumérica (letras y números)');
            updateRequirement(reqSpecial, hasSpecial, 'Un carácter especial (@, $, !, %, etc.)');

            isResetPasswordValid = isLengthValid && hasLetters && hasNumbers && hasSpecial;

            if (isResetPasswordValid) {
                if (strengthText) {
                    strengthText.textContent = 'Estado: Contraseña Muy Segura';
                    strengthText.style.color = '#198754';
                }
            } else {
                if (strengthText) {
                    strengthText.textContent = 'Estado: Contraseña Poco Segura';
                    strengthText.style.color = '#dc3545';
                }
            }
        });
    }

if (resetPasswordForm) {
        resetPasswordForm.addEventListener('submit', function (event) {
            if (!isResetPasswordValid) {
                event.preventDefault();
                mostrarAlertaTBR(
                    'Atención',
                    'Tu contraseña no cumple con los criterios de seguridad',
                    resetPasswordInput
                );
                return;
            }

            if (
                !resetPasswordConfirmationInput ||
                resetPasswordConfirmationInput.value !== resetPasswordInput.value
            ) {
                event.preventDefault();
                mostrarAlertaTBR(
                    'Atención',
                    'Tus contraseñas no coinciden',
                    resetPasswordConfirmationInput
                );
                return;
            }
        });
    }

});