<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar contraseña - The Beauty Room</title>
    @vite(['resources/css/auth.css'])
</head>
<script src="https://unpkg.com/lucide@latest"></script>
<body class="login-container">

    <main class="split-layout">
        <section class="image-side">
            <div class="overlay">
                <h1>Recupera tu acceso.</h1>
                <p>THE BEAUTY ROOM</p>
            </div>
        </section>

        <section class="form-side">
            <div class="form-inner">
                <header>
                    <i data-lucide="key-round" style="width: 16px; height: 16px; color: #8b5e3c; margin-right: 5px; display: inline-block; vertical-align: middle;"></i>
                    <small>RECUPERACIÓN</small>
                    <h1>¿Olvidaste tu contraseña?</h1>
                    <p style="margin-bottom: 20px;">Ingresa tu correo electrónico y te enviaremos los pasos para crear una nueva.</p>
                </header>

                <form id="forgot-password-form" method="POST" action="{{ route('password.email') }}">
                    @csrf
                    
                    <div class="form-row">
                        <label for="email">CORREO ELECTRÓNICO</label>
                        <input id="email" name="email" type="email" placeholder="tu@correo.com" required>
                    </div>

                    <button type="submit" class="btn-primary">ENVIAR ENLACE</button>
                    
                    <p class="register-link">
                        <a href="{{ route('login.view') }}">Volver al inicio de sesión</a>
                    </p>
                </form>
            </div>
        </section>
    </main>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>