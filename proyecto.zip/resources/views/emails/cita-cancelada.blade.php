<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cita cancelada</title>
</head>
<body style="margin: 0; padding: 24px; background: #f6f3eb; color: #333; font-family: Arial, sans-serif;">
    {{-- Contenedor visual del correo para mantener el mensaje centrado y legible. --}}
    <main style="max-width: 600px; margin: 0 auto; padding: 32px; border-radius: 12px; background: #fff;">
        {{-- Saluda al cliente por su nombre y anuncia que la cita quedó confirmada. --}}
        <h1 style="color: #8b5e3c;">¡Tu cita ha sido cancelada, {{ $cita->cliente->nombre }}!</h1>
        {{-- Muestra el servicio asociado a la cita; usa un texto alternativo si no existe. --}}
        <p>El equipo de The Beauty Room canceló tu cita para <strong>{{ $cita->servicio->nombre_servicio ?? 'tu servicio' }}</strong>.</p>
        <p>
            {{-- Presenta la fecha de la cita en formato día/mes/año. --}}
            <strong>Fecha:</strong> {{ $cita->fecha->format('d/m/Y') }}<br>
            {{-- Presenta la hora de la cita en formato de 12 horas. --}}
            <strong>Hora:</strong> {{ \Carbon\Carbon::parse($cita->hora)->format('h:i A') }}
        </p>
        @if($motivo)
            {{-- Explica al cliente el motivo que se registró al cancelar la cita. --}}
            <p><strong>Motivo de cancelación:</strong> {{ $motivo }}</p>
        @endif
        @if($montoReembolso > 0 && $reembolsoPorDefinir)
            <p>
                Se te reembolsará un importe de <strong>${{ number_format($montoReembolso, 2) }}</strong>.
                El monto adicional aún está por definirse; te informaremos cuando quede confirmado.
            </p>
        @elseif($montoReembolso > 0)
            <p>
                Se te reembolsará <strong>${{ number_format($montoReembolso, 2) }}</strong>.
                El reembolso está pendiente de procesarse.
            </p>
        @elseif($reembolsoPorDefinir)
            <p>
                Se gestionará un reembolso por tu pago. El importe está pendiente de definición
                y te informaremos cuando quede confirmado.
            </p>
        @endif
        {{-- Indica que puede comunicarse con el negocio si necesita más información. --}}
        <p>Si tienes dudas, comunícate con The Beauty Room.</p>
        {{-- Identifica al negocio que envía el aviso. --}}
        <p style="color: #777;">The Beauty Room</p>
    </main>
</body>
</html>
